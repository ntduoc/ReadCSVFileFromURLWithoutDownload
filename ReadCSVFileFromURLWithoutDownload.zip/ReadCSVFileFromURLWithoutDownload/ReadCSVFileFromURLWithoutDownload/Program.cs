﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ReadCSVFileFromURLWithoutDownload
{
    class Program
    {
        static void Main(string[] args)
        {
            ReadCsvOnline readCsvOnline = new ReadCsvOnline();
            readCsvOnline.Url = "https://support.spatialkey.com/wp-content/uploads/2021/02/TechCrunchcontinentalUSA.csv";
            string[] csvHeader = readCsvOnline.CsvHeaders();
            for (int i = 0; i < csvHeader.Length; i++)
            {
                Console.WriteLine(csvHeader[i]);
            }
            Console.ReadKey();
            string content = readCsvOnline.CsvContent().ToString();
            string[] arrContent = content.Split(';');
            for(int i=0; i < arrContent.Length; i++)
            {
                Console.WriteLine(arrContent[i]);
            }
            Console.ReadKey();
        }
    }
}
